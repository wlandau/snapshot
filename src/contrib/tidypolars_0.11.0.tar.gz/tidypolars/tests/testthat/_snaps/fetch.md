# can only be used on LazyFrame

    Code
      fetch(pl$DataFrame(iris))
    Condition
      Error in `fetch()`:
      ! `fetch()` can only be used on a LazyFrame.

