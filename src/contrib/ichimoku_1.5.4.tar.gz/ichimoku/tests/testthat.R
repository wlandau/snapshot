library(testthat)
library(ichimoku)

test_check("ichimoku")
