## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(polars)
library(tidypolars)
library(dplyr, warn.conflicts = FALSE)
library(tidyr, warn.conflicts = FALSE)

who_df <- tidyr::who
who_pl <- as_polars_df(tidyr::who)

## -----------------------------------------------------------------------------
who_df |>
  filter(year > 1990) |>
  drop_na(newrel_f3544) |>
  select(iso3, year, matches("^newrel(.*)_f")) |>
  arrange(iso3, year) |>
  rename_with(.fn = toupper) |>
  head()

## -----------------------------------------------------------------------------
who_pl |>
  filter(year > 1990) |>
  drop_na(newrel_f3544) |>
  select(iso3, year, matches("^newrel(.*)_f")) |>
  arrange(iso3, year) |>
  rename_with(.fn = toupper) |>
  head()

## -----------------------------------------------------------------------------
who_pl_lazy <- as_polars_lf(tidyr::who)

who_pl_lazy |>
  filter(year > 1990) |>
  drop_na(newrel_f3544) |>
  select(iso3, year, matches("^newrel(.*)_f")) |>
  arrange(iso3, year) |>
  rename_with(.fn = toupper) |>
  compute() |>
  head()

