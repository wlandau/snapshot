## -----------------------------------------------------------------------------
library(webseq)

## ----eval = FALSE-------------------------------------------------------------
# ncbi_download_genome("GCF_003007635.1", type = "genomic.gbff")

## ----eval = FALSE-------------------------------------------------------------
# ncbi_download_genome("GCF_003007635.1", type = "genomic.gbff")

## ----eval = FALSE-------------------------------------------------------------
# assembly_meta <- ncbi_get_meta("GCF_003007635.1", db = "assembly")

## ----eval = FALSE-------------------------------------------------------------
# biosample_uid <- ncbi_get_uid(assembly_meta$biosample, db = "biosample")
# biosample_uid

## ----eval = FALSE-------------------------------------------------------------
# biosample_meta <- get_meta(biosample_uid$uid, db = "biosample")
# biosample_meta

## ----eval = FALSE-------------------------------------------------------------
# ncbi_parse_assembly_xml("assembly_summary.xml")

## ----eval = FALSE-------------------------------------------------------------
# ncbi_parse_biosample_txt("biosample_summary.txt")

