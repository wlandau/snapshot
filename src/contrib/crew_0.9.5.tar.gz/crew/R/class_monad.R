monad_init <- function(
  name = NA_character_,
  command = NA_character_,
  result = NA,
  seconds = NA_real_,
  seed = NA_integer_,
  algorithm = NA_character_,
  error = NA_character_,
  trace = NA_character_,
  warnings = NA_character_,
  launcher = NA_character_,
  worker = NA_integer_,
  instance = NA_character_
) {
  out <- monad_new(
    name = name,
    command = command,
    result = list(result),
    seconds = seconds,
    seed = seed,
    algorithm = algorithm,
    error = error,
    trace = trace,
    warnings = warnings,
    launcher = launcher,
    worker = worker,
    instance = instance
  )
  out
}

monad_new <- function(
  name = NULL,
  command = NULL,
  result = NULL,
  seconds = NULL,
  seed = NULL,
  algorithm = NULL,
  error = NULL,
  trace = NULL,
  warnings = NULL,
  launcher = NULL,
  worker = NULL,
  instance = NULL
) {
  list(
    name = name,
    command = command,
    result = result,
    seconds = seconds,
    seed = seed,
    algorithm = algorithm,
    error = error,
    trace = trace,
    warnings = warnings,
    launcher = launcher,
    worker = worker,
    instance = instance
  )
}

monad_validate <- function(monad) {
  crew_assert(is.list(monad))
  crew_assert(identical(names(monad), names(formals(monad_new))))
  cols <- c(
    "name",
    "command",
    "algorithm",
    "error",
    "trace",
    "warnings",
    "launcher",
    "instance"
  )
  for (col in cols) {
    crew_assert(monad[[col]], is.character(.), length(.) == 1L)
  }
  for (col in c("seconds", "seed")) {
    crew_assert(monad[[col]], is.numeric(.), length(.) == 1L)
  }
  crew_assert(monad$worker, is.integer(.), length(.) == 1L)
  crew_assert(monad$result, is.list(.), length(.) == 1L)
  invisible()
}

monad_tibble <- function(monad) {
  attributes(monad) <- list(
    names = monad_names,
    class = c("tbl_df", "tbl", "data.frame"),
    row.names = monad_rownames
  )
  monad
}

monad_names <- names(formals(monad_new))
monad_names_n <- length(monad_names)
monad_rownames <- .set_row_names(1L)
