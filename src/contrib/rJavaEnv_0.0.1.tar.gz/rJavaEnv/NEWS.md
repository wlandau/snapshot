## version 0.0.1

---


### Initial release

- Initial release


## version 0.0.0.9000

---

### NEWS.md setup

- added NEWS.md creation with [newsmd](https://github.com/Dschaykib/newsmd)

