# name of output column must be provided

    Code
      current$collect()
    Condition
      Error in `unite()`:
      ! `col` is absent but must be supplied.

