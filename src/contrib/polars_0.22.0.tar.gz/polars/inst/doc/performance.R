## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)
options(rmarkdown.html_vignette.check_title = FALSE)

## -----------------------------------------------------------------------------
countries = c(
  "France", "Germany", "United Kingdom", "Japan", "Columbia",
  "South Korea", "Vietnam", "South Africa", "Senegal", "Iran"
)

set.seed(123)
test = data.frame(
  country = sample(countries, 1e6, TRUE),
  x = sample(1:100, 1e6, TRUE),
  y = sample(1:1000, 1e6, TRUE)
)

## -----------------------------------------------------------------------------
library(polars)

set.seed(123)
df_test = pl$DataFrame(
  country = sample(countries, 1e7, TRUE),
  x = sample(1:100, 1e7, TRUE),
  y = sample(1:1000, 1e7, TRUE)
)

lf_test = df_test$lazy()

## -----------------------------------------------------------------------------
df_test$
  sort(pl$col("country"))$
  filter(
  pl$col("country")$is_in(pl$lit(c("United Kingdom", "Japan", "Vietnam")))
)

## -----------------------------------------------------------------------------
lazy_query = lf_test$
  sort(pl$col("country"))$
  filter(
  pl$col("country")$is_in(pl$lit(c("United Kingdom", "Japan", "Vietnam")))
)

lazy_query

## -----------------------------------------------------------------------------
lazy_query$explain(optimized = FALSE) |>
  cat()

lazy_query$explain() |>
  cat()

