
int calc_serialized_size(SEXP robj);
