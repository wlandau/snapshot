# Precomplie vignettes locally
# More info here: https://ropensci.org/technotes/2019/12/08/precompute-vignettes/
library(knitr)
knit("vignettes/webchem.Rmd.orig", "vignettes/webchem.Rmd") #Get Started
