# error cases work

    Code
      current$collect()
    Condition
      Error in `pull()`:
      ! `pull` can only extract one column. You tried to extract 2.

---

    Code
      current$collect()
    Condition
      Error in `pull()`:
      ! Arguments in `...` must be used.
      x Problematic argument:
      * ..1 = hp
      i Did you misspell an argument name?

