
SEXP zstd_compress_stream_file_(SEXP robj, SEXP file_, SEXP cctx_, SEXP opts_);
SEXP zstd_decompress_stream_file_(SEXP src_, SEXP type_, SEXP dctx_, SEXP opts_);
