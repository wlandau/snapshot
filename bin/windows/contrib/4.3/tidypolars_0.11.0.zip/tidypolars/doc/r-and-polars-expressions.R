## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----echo=FALSE---------------------------------------------------------------
library(dplyr, warn.conflicts = FALSE)

## ----eval=FALSE---------------------------------------------------------------
#  library(dplyr, warn.conflicts = FALSE)
#  
#  filter(mtcars, am + gear > carb)
#  mutate(mtcars, x = (qsec - mean(qsec)) / sd(qsec))
#  mtcars |>
#    group_by(cyl) |>
#    summarize(x = mean(qsec) / sd(qsec))

## -----------------------------------------------------------------------------
library(tidypolars)
library(polars)

mtcars |> 
  as_polars_df() |> 
  mutate(x = mean(mpg, trim = 2))

## -----------------------------------------------------------------------------
pl_standardize <- function(x) {
  (x - x$mean()) / x$std()
}

## -----------------------------------------------------------------------------
pl_standardize(pl$col("mpg"))

## -----------------------------------------------------------------------------
mtcars |> 
  as_polars_df() |> 
  mutate(x = pl_standardize(mpg))

## -----------------------------------------------------------------------------
mtcars |> 
  as_polars_df() |> 
  mutate(
    across(
      .cols = contains("a"),
      list(mean = mean, stand = pl_standardize, ~ sd(.x))
    )
  )

## ----error=TRUE---------------------------------------------------------------
mtcars |> 
  as_polars_df() |> 
  mutate(
    across(
      .cols = contains("a"),
      .fns = list(
        mean = mean,  
        function(x) {
           (x - mean(x)) / sd(x)
        },
        ~ sd(.x)
      )
    )
  )

## ----echo=FALSE, message=FALSE------------------------------------------------
library(dplyr)
library(knitr)
out <- tribble(
  ~Package, ~Function,
  "`base`",             "`abs`",
  "`base`",             "`acos`", 
  "`base`",             "`acosh`", 
  "`base`",             "`all`",
  "`base`",             "`any`",
  "`base`",             "`asin`",
  "`base`",             "`asinh`", 
  "`base`",             "`atan`", 
  "`base`",             "`atanh`",
  "`base`",             "`ceiling`",
  "`base`",             "`cos`", 
  "`base`",             "`cosh`",
  "`base`",             "`cummin`",
  "`base`",             "`cumsum`", 
  "`base`",             "`diff`", 
  "`base`",             "`exp`", 
  "`base`",             "`floor`",
  "`base`",             "`grepl`",
  "`base`",             "`ifelse`",
  "`base`",             "`ISOdatetime`",
  "`base`",             "`length`",
  "`base`",             "`log`", 
  "`base`",             "`log10`",
  "`base`",             "`max`", 
  "`base`",             "`mean`", 
  "`base`",             "`min`",
  "`base`",             "`nchar`",
  "`base`",             "`paste0`",
  "`base`",             "`paste`",
  "`base`",             "`rank`",
  "`base`",             "`rev`",
  "`base`",             "`round`",
  "`base`",             "`sin`", 
  "`base`",             "`sinh`", 
  "`base`",             "`sort`", 
  "`base`",             "`sqrt`", 
  "`base`",             "`strptime`",
  "`base`",             "`substr`",
  "`base`",             "`tan`", 
  "`base`",             "`tanh`",
  "`base`",             "`tolower`",
  "`base`",             "`toupper`",
  "`base`",             "`unique`",
  "`base`",             "`which.min`",
  "`base`",             "`which.max`",
  "`dplyr`",            "`between`",
  "`dplyr`",            "`case_match`",
  "`dplyr`",            "`case_when`",
  "`dplyr`",            "`coalesce`",
  "`dplyr`",            "`consecutive_id`",
  "`dplyr`",            "`dense_rank`",
  "`dplyr`",            "`first`",
  "`dplyr`",            "`group_keys`",
  "`dplyr`",            "`group_vars`",
  "`dplyr`",            "`if_else`",
  "`dplyr`",            "`lag`",
  "`dplyr`",            "`last`",
  "`dplyr`",            "`min_rank`",
  "`dplyr`",            "`n`",
  "`dplyr`",            "`nth`",
  "`dplyr`",            "`n_distinct`",
  "`dplyr`",            "`row_number`",
  "`lubridate`",        "`ddays`",
  "`lubridate`",        "`dhours`",
  "`lubridate`",        "`dmilliseconds`",
  "`lubridate`",        "`dminutes`",
  "`lubridate`",        "`dseconds`",
  "`lubridate`",        "`dweeks`",
  "`lubridate`",        "`make_date`",
  "`lubridate`",        "`make_datetime`",
  "`lubridate`",        "`wday`",
  "`stats`",            "`median`", 
  "`stats`",            "`lag`", 
  "`stats`",            "`sd`", 
  "`stats`",            "`var`",
  "`stringr`",          "`regex`",
  "`stringr`",          "`str_count`",
  "`stringr`",          "`str_detect`",
  "`stringr`",          "`str_dup`",
  "`stringr`",          "`str_ends`",
  "`stringr`",          "`str_extract`",
  "`stringr`",          "`str_extract_all`",
  "`stringr`",          "`str_length`",
  "`stringr`",          "`str_pad`",
  "`stringr`",          "`str_remove`",
  "`stringr`",          "`str_remove_all`",
  "`stringr`",          "`str_replace`",
  "`stringr`",          "`str_replace_all`",
  "`stringr`",          "`str_split`",
  "`stringr`",          "`str_split_i`",
  "`stringr`",          "`str_squish`",
  "`stringr`",          "`str_starts`",
  "`stringr`",          "`str_sub`",
  "`stringr`",          "`str_trim`",
  "`stringr`",          "`str_to_lower`",
  "`stringr`",          "`str_to_title`",
  "`stringr`",          "`str_to_upper`",
  "`stringr`",          "`str_trunc`",
  "`stringr`",          "`word`",
  "`tidyr`",            "`replace_na`",
  "`tools`",            "`toTitleCase`"
) |>
  mutate(Notes = case_when(
    Package == "`lubridate`" & Function == "`make_datetime`" ~ "In `lubridate::make_datetime()`, when there is an overflow (for example `hours = 25`), then it is automatically converted to the higher unit (for example 1 day and 1h). In Polars, this returns `NA`.",
    Package == "`lubridate`" & Function == "`wday`" ~ "Requires `week_start == 7`. If `label = TRUE`, it returns a string variable and not a factor as in `lubridate`.",
    Package == "`dplyr`" & Function == "`row_number`" ~ "Doesn't work when `x` is missing.",
    Package == "`stringr`" & Function == "`str_to_title`" ~ "Letters following apostrophe will be capitalized as well, which differs from the `stringr` implementation.",
    Package == "`tools`" & Function == "`toTitleCase`" ~ "Letters following apostrophe will be capitalized as well, which differs from the `tools` implementation.",
    .default = ""
  )) |> 
  arrange(Package)

kable(out) 

