library(testthat)
library(zstdlite)

test_check("zstdlite")
