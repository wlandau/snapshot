#' @noRd
#' @keywords internal
"_PACKAGE"
