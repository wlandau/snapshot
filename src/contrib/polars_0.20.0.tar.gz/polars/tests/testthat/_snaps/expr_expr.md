# reshape

    Code
      out$schema
    Output
      $foo
      DataType: Array(
          Array(
              Int32,
              2,
          ),
          2,
      )
      

