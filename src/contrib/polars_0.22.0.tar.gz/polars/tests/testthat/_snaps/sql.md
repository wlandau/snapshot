# Intialize SQLContext with LazyFrame like objects

    Code
      ctx
    Output
      RPolarsSQLContext
        tables: pl_df pl_lf r_df 

