# arrow_scalar_function() works

    fun is not a function

