# only works on polars dataframe

    Code
      write_csv_polars(mtcars)
    Condition
      Error in `write_csv_polars()`:
      ! `write_csv_polars()` can only be used on a DataFrame.

---

    Code
      write_ipc_polars(mtcars)
    Condition
      Error in `write_ipc_polars()`:
      ! `write_ipc_polars()` can only be used on a DataFrame.

---

    Code
      write_json_polars(mtcars)
    Condition
      Error in `write_json_polars()`:
      ! `write_json_polars()` can only be used on a DataFrame.

---

    Code
      write_ndjson_polars(mtcars)
    Condition
      Error in `write_ndjson_polars()`:
      ! `write_ndjson_polars()` can only be used on a DataFrame.

---

    Code
      write_parquet_polars(mtcars)
    Condition
      Error in `write_parquet_polars()`:
      ! `write_parquet_polars()` can only be used on a DataFrame.

