# asylum 1.1.1

- Updated to June 2023 datasets

# asylum 1.1.0

- Updated to March 2023 datasets
- Added new datasets: grant rates (quarterly and annual), inadmissibility statistics, notices of intent, asylum applications/outcomes and NRM referrals/outcomes from small boats arrivals, average daily costs of detention, and pregnant women in detention.

# asylum 1.0.3

- Updated to December 2022 datasets

# asylum 1.0.2

- Updated to June 2022 datasets

# asylum 1.0.1

- Added URLs to the 'description' field of `DESCRIPTION` listing the web services used

# asylum 1.0.0

- Added all Home Office asylum and resettlement datasets
