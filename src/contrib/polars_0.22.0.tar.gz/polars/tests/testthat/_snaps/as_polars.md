# tests for vctrs_rcrd

    Code
      pl$DataFrame(foo = vec)$dtypes
    Output
      [[1]]
      DataType: Struct(
          [
              Field {
                  name: "lat",
                  dtype: Float64,
              },
              Field {
                  name: "lon",
                  dtype: Float64,
              },
          ],
      )
      

