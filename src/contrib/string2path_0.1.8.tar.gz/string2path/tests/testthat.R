library(testthat)
library(string2path)

test_check("string2path")
