library(testthat)
library(multiverse.internals)

test_check("multiverse.internals")
