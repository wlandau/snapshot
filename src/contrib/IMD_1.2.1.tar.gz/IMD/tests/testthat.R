library(testthat)
library(IMD)

test_check("IMD")
