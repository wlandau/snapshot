# can't collect non-LazyFrame object

    Code
      collect(pl_iris)
    Condition
      Error in `UseMethod()`:
      ! no applicable method for 'collect' applied to an object of class "RPolarsDataFrame"

