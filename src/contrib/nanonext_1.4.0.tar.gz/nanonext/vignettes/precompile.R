# Vignettes precompiled as require setup of communications between separate processes, python etc.
knitr::knit("vignettes/nanonext.Rmd.orig", "vignettes/nanonext.Rmd")
