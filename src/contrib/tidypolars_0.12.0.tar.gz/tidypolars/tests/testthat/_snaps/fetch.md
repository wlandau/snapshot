# can only be used on LazyFrame

    Code
      fetch(as_polars_df(iris))
    Condition
      Error in `fetch()`:
      ! `fetch()` can only be used on a LazyFrame.

