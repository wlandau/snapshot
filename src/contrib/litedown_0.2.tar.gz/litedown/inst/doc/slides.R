cat(1:10, sep = "\n")

