# error if variable doesn't exist

    Code
      current$collect()
    Condition
      Error in `drop_na()`:
      ! Can't select columns that don't exist.
      x Column `foo` doesn't exist.

